#!/bin/bash=
inst="iypstagingstg smelisting smestg yellowpagessg ypmarketplastg ypsg ypverizon"