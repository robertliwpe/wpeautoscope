#!/bin/bash=
inst="devmoodlenet moodlecom moodlemootorg newmoodle newmoodledev newmoodlestage oldmoodle openedtech"