#!/bin/bash=
inst=""